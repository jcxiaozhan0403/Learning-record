import junit.framework.TestCase;

/**
 * @author John.Cena
 * @date 2022/9/29 11:36
 * @Description:
 */
// 15题测试程序
public class Demo15Test extends TestCase {

}