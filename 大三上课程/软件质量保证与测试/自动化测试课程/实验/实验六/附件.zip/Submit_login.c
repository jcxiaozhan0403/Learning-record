Submit_login()
{

	//填写信息，点击登录
	web_custom_request("login", 
		"URL=http://47.108.64.145:8080/user/login", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("login_2", 
		"URL=http://47.108.64.145:8080/user/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://test.jcxiaozhan.top/login?redirect=%2Fdashboard", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=utf-8", 
		"Body={\"username\":\"JohnCena\",\"password\":\"123456\"}", 
		LAST);

	web_url("info_2", 
		"URL=http://47.108.64.145:8080/user/info?token=c0de3f6b-8479-4283-bdbe-e22279384b6f", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://test.jcxiaozhan.top/login?redirect=%2Fdashboard", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("vue_admin_template_token=c0de3f6b-8479-4283-bdbe-e22279384b6f; DOMAIN=test.jcxiaozhan.top");

	return 0;
}
