Data_Select()
{
	//获取图表数据
	web_custom_request("list", 
		"URL=http://47.108.64.145:8080/student/list", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("list_2", 
		"URL=http://47.108.64.145:8080/teacher/list", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("list_3", 
		"URL=http://47.108.64.145:8080/clazz/list", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);
	
	//结束事务点
	lr_end_transaction("sign",LR_AUTO);
	
	return 0;
}