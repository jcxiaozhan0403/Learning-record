Open_index()
{
	//开始事务点
	lr_start_transaction("sign");
	
	//打开首页
	web_url("test.jcxiaozhan.top", 
		"URL=http://test.jcxiaozhan.top/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
