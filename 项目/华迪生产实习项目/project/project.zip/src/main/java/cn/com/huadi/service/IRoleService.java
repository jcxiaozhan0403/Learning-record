package cn.com.huadi.service;

import cn.com.huadi.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yuan点
 * @since 2021-11-06
 */
public interface IRoleService extends IService<Role> {

}
