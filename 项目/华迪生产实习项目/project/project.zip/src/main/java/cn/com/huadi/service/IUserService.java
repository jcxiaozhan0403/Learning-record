package cn.com.huadi.service;

import cn.com.huadi.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yuan点
 * @since 2021-11-06
 */
public interface IUserService extends IService<User> {

}
