package cn.com.huadi.mapper;

import cn.com.huadi.entity.Curriculum;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yuan点
 * @since 2021-11-06
 */
public interface CurriculumMapper extends BaseMapper<Curriculum> {

}
