export const cwUrl="http://192.168.3.22:5000/cwApi";

//export const cwUrl="https://cw.mszlu.com/cwApi";